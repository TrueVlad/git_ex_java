package com.egortroyan.searchengine.service.responses;

public interface ResponseService {

    boolean getResult() ;
}
