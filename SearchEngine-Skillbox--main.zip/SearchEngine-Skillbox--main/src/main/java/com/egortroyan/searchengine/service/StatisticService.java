package com.egortroyan.searchengine.service;

import com.egortroyan.searchengine.service.responses.StatisticResponseService;

public interface StatisticService {
    StatisticResponseService getStatistic();
}
