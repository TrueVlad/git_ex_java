package com.egortroyan.searchengine.service.responses;

public class TrueResponseService implements ResponseService {

    @Override
    public boolean getResult() {
        return true;
    }
}
