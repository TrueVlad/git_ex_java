package com.egortroyan.searchengine.models;

public enum Status {
    INDEXING,
    INDEXED,
    FAILED
}
