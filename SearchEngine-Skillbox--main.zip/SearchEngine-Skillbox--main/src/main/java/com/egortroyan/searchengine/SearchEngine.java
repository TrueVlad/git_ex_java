package com.egortroyan.searchengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchEngine {
    public static void main(String[] args) {
        SpringApplication.run(SearchEngine.class, args);
    }
}
